from controller import Supervisor
import numpy as np
import json

# Inicializar supervisor
robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

# Parámetros del grid
GRID_RESOLUTION = 0.04
WORLD_X_MIN, WORLD_X_MAX = -0.5, 0.5
WORLD_Y_MIN, WORLD_Y_MAX = -0.5, 0.5
GRID_WIDTH = int((WORLD_X_MAX - WORLD_X_MIN) / GRID_RESOLUTION)
GRID_HEIGHT = int((WORLD_Y_MAX - WORLD_Y_MIN) / GRID_RESOLUTION)
grid = np.zeros((GRID_HEIGHT, GRID_WIDTH), dtype=int)

def world_to_grid(x, y):
    gx = int((x - WORLD_X_MIN) / GRID_RESOLUTION)
    gy = int((y - WORLD_Y_MIN) / GRID_RESOLUTION)
    return gy, gx  # fila, columna

def mark_obstacle(x, y, sx, sy, value):
    x_min, x_max = x - sx/2, x + sx/2
    y_min, y_max = y - sy/2, y + sy/2
    gy_min, gx_min = world_to_grid(x_min, y_min)
    gy_max, gx_max = world_to_grid(x_max, y_max)
    for i in range(gy_min, gy_max+1):
        for j in range(gx_min, gx_max+1):
            if 0 <= i < GRID_HEIGHT and 0 <= j < GRID_WIDTH:
                grid[j, i] = value

# 🧱 Paredes
walls = [
    (0.29, 0.36, 0.01, 0.3),
    (0.29, -0.36, 0.01, 0.3),
    (-0.29, 0.36, 0.01, 0.3),
    (-0.29, -0.04, 0.01, 0.3),
    (-0.4, 0.05, 0.22, 0.01),
    (-0.18, 0.32, 0.22, 0.01),
    (0.18, 0.32, 0.22, 0.01),
    (0.39, 0.0, 0.22, 0.01),
    (0.07, -0.36, 0.01, 0.3),
    (-0.15, -0.36, 0.01, 0.3),
    (0.28, 0.0, 0.01, 0.2),
    (0.07, -0.21, 0.22, 0.01),
    (0.0, 0.36, 0.01, 0.3)
]

# 📦 Cajas
boxes = [
    ("BOX_1", 0.31, 0.03, 0.05, 0.05),
    ("BOX_2", 0.1, 0.35, 0.05, 0.05),
    ("BOX_3", -0.1, 0.35, 0.05, 0.05),
    ("BOX_4", 0.31, -0.03, 0.05, 0.05),
    ("BOX_5", -0.32, 0.08, 0.05, 0.05),
    ("BOX_6", 0.1, -0.24, 0.05, 0.05),
    ("BOX_7", 0.04, -0.24, 0.05, 0.05),
    ("BOX_8", -0.47, -0.35, 0.05, 0.3)
]

# Marcar obstáculos
for x, y, sx, sy in walls:
    mark_obstacle(x, y, sx, sy, 1)
for name, x, y, sx, sy in boxes:
    mark_obstacle(x, y, sx, sy, 2)

# 📍 Calcular coordenadas de cada caja en el GRID
pickup_grid_coords = {}
for name, x, y, _, _ in boxes:
    gy, gx = world_to_grid(y, x)
    pickup_grid_coords[name] = [gy, gx]

# 📦 Posición de entrega lógica (BOX_8)
delivery_grid = pickup_grid_coords["BOX_8"]

# 📤 Enviar datos al recogedor
emitter = robot.getDevice("emitter(1)")
data = {
    "target": "ROBOT_2",
    "grid": grid.tolist(),
    "pickup_target": "BOX_3",
    "pickup_grid": pickup_grid_coords,
    "delivery_grid": delivery_grid,
    "grid_resolution": GRID_RESOLUTION,
    "grid_height": GRID_HEIGHT,
    "world_x_min": WORLD_X_MIN,
    "world_y_min": WORLD_Y_MIN
}

np.set_printoptions(threshold=np.inf)
print("GRID:")
print(grid)
emitter.send(json.dumps(data))

while robot.step(timestep) != -1:
    pass
