import math
import struct
from controller import Robot, Motor, DistanceSensor, GPS, Emitter, Receiver, Compass

# --- Configuración Inicial ---
robot = Robot()
robot_name = robot.getName()
timestep = int(robot.getBasicTimeStep())

# Punto de destino (ej. una esquina del laboratorio)
TARGET_POINT = [0.4, -0.4]

# --- Configuración de Dispositivos ---
# Motores
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Sensores de Proximidad
ps = [robot.getDevice(f'ps{i}') for i in range(8)]
for sensor in ps:
    sensor.enable(timestep)

# GPS, Emitter, Receiver
gps = robot.getDevice('gps')
gps.enable(timestep)
emitter = robot.getDevice('emitter')
receiver = robot.getDevice('receiver')
receiver.enable(timestep)

# Brújula (Compass)
compass = robot.getDevice('compass')
compass.enable(timestep)

# --- Bucle Principal ---
while robot.step(timestep) != -1:
    # --- Obtener Datos Actuales ---
    pos = gps.getValues()  # Posición actual (x, y, z)
    compass_values = compass.getValues() # Orientación actual

    # Calcular el ángulo actual del robot
    # La brújula da un vector, usamos atan2 para convertirlo a un ángulo en radianes
    robot_angle = math.atan2(compass_values[0], compass_values[2])

    # Calcular el ángulo hacia el punto de destino
    target_angle = math.atan2(TARGET_POINT[0] - pos[0], TARGET_POINT[1] - pos[2])

    # Calcular la diferencia de ángulo (cuánto necesita girar el robot)
    angle_diff = robot_angle - target_angle
    # Normalizar el ángulo para que esté entre -PI y PI
    if angle_diff > math.pi: angle_diff -= 2 * math.pi
    if angle_diff < -math.pi: angle_diff += 2 * math.pi
    
    # --- Lógica de Evasión de Obstáculos (Braitenberg) ---
    ps_values = [sensor.getValue() for sensor in ps]
    UMBRAL_OBSTACULO = 70.0
    obstaculo_izquierda = ps_values[5] > UMBRAL_OBSTACULO or ps_values[6] > UMBRAL_OBSTACULO
    obstaculo_derecha = ps_values[0] > UMBRAL_OBSTACULO or ps_values[1] > UMBRAL_OBSTACULO
    
    # --- Lógica de Decisión Combinada ---
    velocidad_base = 4.0
    velocidad_izquierda = velocidad_base
    velocidad_derecha = velocidad_base

    if obstaculo_izquierda or obstaculo_derecha:
        # Prioridad 1: Si hay un obstáculo, esquivarlo
        if obstaculo_izquierda:
            velocidad_izquierda += 2.0
            velocidad_derecha -= 2.0
        elif obstaculo_derecha:
            velocidad_izquierda -= 2.0
            velocidad_derecha += 2.0
    else:
        # Prioridad 2: Si no hay obstáculo, dirigirse al objetivo
        # Usamos la diferencia de ángulo para ajustar las ruedas y girar
        velocidad_izquierda += angle_diff
        velocidad_derecha -= angle_diff

    # Asignamos la velocidad final a los motores
    left_motor.setVelocity(velocidad_izquierda)
    right_motor.setVelocity(velocidad_derecha)
    
    # --- Comunicación (sigue igual) ---
    message = f"{robot_name},{pos[0]},{pos[2]}".encode('utf-8')
    emitter.send(message)
    
    while receiver.getQueueLength() > 0:
        received_string = receiver.getString()
        parts = received_string.split(',')
        sender_name = parts[0]
        if sender_name != robot_name:
            sender_pos_x = float(parts[1])
            sender_pos_z = float(parts[2])
            print(f"Soy [{robot_name}] y he recibido de [{sender_name}] -> Pos: ({sender_pos_x:.2f}, {sender_pos_z:.2f})")
        receiver.nextPacket()