from controller import Robot, Motor, DistanceSensor, GPS, Receiver, Emitter
import math

robot = Robot()
timestep = int(robot.getBasicTimeStep())
ROBOT_ID = 1  # Cambia este valor para cada robot

# --- Dispositivos ---
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

gps = robot.getDevice('gps')
gps.enable(timestep)

ps = [robot.getDevice(f'ps{i}') for i in range(8)]
for sensor in ps:
    sensor.enable(timestep)

receiver = robot.getDevice('receiver(1)')
receiver.setChannel(ROBOT_ID)
receiver.enable(timestep)

emitter = robot.getDevice('emitter(1)')

# --- Estados ---
AVANZAR = 0
RETROCEDER = 1
GIRAR = 2
IR_A_OBJETIVO = 3
estado = AVANZAR
retro_steps = 0
giro_steps = 0
MAX_RETRO_STEPS = 15
MAX_GIRO_STEPS = 25
giro_direccion = "izquierda"
objetivo = None
siguiente_objetivo = None
libre = True
posiciones_otros = {}

# --- Funciones ---
def detect_obstacle():
    front = ps[0].getValue() > 80 or ps[7].getValue() > 80
    left = ps[1].getValue() > 80 or ps[2].getValue() > 80
    right = ps[5].getValue() > 80 or ps[6].getValue() > 80
    return front, left, right

def ir_a_objetivo(x, z):
    pos = gps.getValues()
    dx = x - pos[0]
    dz = z - pos[2]
    if abs(dx) < 0.02 and abs(dz) < 0.02:
        return True
    left_motor.setVelocity(3.0)
    right_motor.setVelocity(3.0)
    return False

def evitar_colision():
    pos = gps.getValues()
    for other_id, (ox, oz) in posiciones_otros.items():
        if other_id != ROBOT_ID:
            dist = math.hypot(pos[0] - ox, pos[2] - oz)
            if dist < 0.08:
                left_motor.setVelocity(-2.0)
                right_motor.setVelocity(-2.0)
                return True
    return False

# --- Inicio: informar disponibilidad ---
emitter.setChannel(0)
emitter.send(f"READY:{ROBOT_ID}".encode('utf-8'))

# --- Bucle principal ---
while robot.step(timestep) != -1:
    # --- Recepción de mensajes ---
    while receiver.getQueueLength() > 0:
        msg = receiver.getData().decode('utf-8')
        if msg.startswith("TASK:"):
            coords = msg.replace("TASK:", "").split(":")
            recojo = tuple(map(float, coords[0].split(",")))
            entrega = tuple(map(float, coords[1].split(",")))
            objetivo = recojo
            siguiente_objetivo = entrega
            estado = IR_A_OBJETIVO
            libre = False
        elif msg.startswith("POS:"):
            parts = msg.split(":")
            other_id = int(parts[1])
            x, z = map(float, parts[2].split(","))
            posiciones_otros[other_id] = (x, z)
        receiver.nextPacket()

    # --- Compartir posición ---
    pos = gps.getValues()
    estado_msg = f"POS:{ROBOT_ID}:{pos[0]:.2f},{pos[2]:.2f}"
    emitter.setChannel(10)
    emitter.send(estado_msg.encode('utf-8'))

    # --- Máquina de estados ---
    if estado == AVANZAR:
        if evitar_colision():
            continue
        front, left, right = detect_obstacle()
        if front:
            estado = RETROCEDER
            retro_steps = MAX_RETRO_STEPS
            giro_direccion = "izquierda" if right else "derecha"
        else:
            left_motor.setVelocity(3.0)
            right_motor.setVelocity(3.0)

    elif estado == RETROCEDER:
        left_motor.setVelocity(-2.0)
        right_motor.setVelocity(-2.0)
        retro_steps -= 1
        if retro_steps <= 0:
            estado = GIRAR
            giro_steps = MAX_GIRO_STEPS

    elif estado == GIRAR:
        if giro_direccion == "izquierda":
            left_motor.setVelocity(-2.0)
            right_motor.setVelocity(2.0)
        else:
            left_motor.setVelocity(2.0)
            right_motor.setVelocity(-2.0)
        giro_steps -= 1
        if giro_steps <= 0:
            estado = AVANZAR

    elif estado == IR_A_OBJETIVO and objetivo:
        if evitar_colision():
            continue
        if ir_a_objetivo(*objetivo):
            if siguiente_objetivo:
                objetivo = siguiente_objetivo
                siguiente_objetivo = None
            else:
                print(f"📦 Robot {ROBOT_ID} entregó objeto")
                emitter.setChannel(0)
                emitter.send(f"DELIVERED:{ROBOT_ID}".encode('utf-8'))
                emitter.send(f"READY:{ROBOT_ID}".encode('utf-8'))
                estado = AVANZAR
                objetivo = None
                libre = True
