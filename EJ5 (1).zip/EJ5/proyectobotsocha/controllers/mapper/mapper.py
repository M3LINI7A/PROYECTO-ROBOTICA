import math
from controller import Robot, Motor, DistanceSensor, GPS

# --- Inicialización del Robot ---
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# --- Dispositivos ---
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

gps = robot.getDevice('gps')
gps.enable(timestep)

ps = [robot.getDevice(f'ps{i}') for i in range(8)]
for sensor in ps:
    sensor.enable(timestep)

# --- Parámetros del Mapeo ---
CELL_SIZE = 0.05
MAP_WIDTH = int(0.5 / CELL_SIZE)
MAP_HEIGHT = int(0.5 / CELL_SIZE)
map_grid = [[-1 for _ in range(MAP_WIDTH)] for _ in range(MAP_HEIGHT)]

# --- Funciones Auxiliares ---
def get_cell_indices(x, z):
    i = int((x + MAP_WIDTH * CELL_SIZE / 2) / CELL_SIZE)
    j = int((z + MAP_HEIGHT * CELL_SIZE / 2) / CELL_SIZE)
    return i, j

def detect_obstacle():
    front = ps[0].getValue() > 80 or ps[7].getValue() > 80
    left = ps[1].getValue() > 80 or ps[2].getValue() > 80
    right = ps[5].getValue() > 80 or ps[6].getValue() > 80
    return front, left, right

# --- Estados ---
AVANZAR = 0
RETROCEDER = 1
GIRAR = 2
estado = AVANZAR
retro_steps = 0
giro_steps = 0
MAX_RETRO_STEPS = 15
MAX_GIRO_STEPS = 25
giro_direccion = "izquierda"

# --- Bucle Principal ---
step_count = 0
while robot.step(timestep) != -1:
    pos = gps.getValues()
    x, z = pos[0], pos[2]
    i, j = get_cell_indices(x, z)

    if 0 <= i < MAP_WIDTH and 0 <= j < MAP_HEIGHT:
        front, left, right = detect_obstacle()
        if front:
            map_grid[j][i] = 1
        else:
            map_grid[j][i] = 0

    # --- Máquina de estados ---
    if estado == AVANZAR:
        front, left, right = detect_obstacle()
        if front:
            estado = RETROCEDER
            retro_steps = MAX_RETRO_STEPS
            giro_direccion = "izquierda" if right else "derecha"
        else:
            left_motor.setVelocity(3.0)
            right_motor.setVelocity(3.0)

    elif estado == RETROCEDER:
        left_motor.setVelocity(-2.0)
        right_motor.setVelocity(-2.0)
        retro_steps -= 1
        if retro_steps <= 0:
            estado = GIRAR
            giro_steps = MAX_GIRO_STEPS

    elif estado == GIRAR:
        if giro_direccion == "izquierda":
            left_motor.setVelocity(-2.0)
            right_motor.setVelocity(2.0)
        else:
            left_motor.setVelocity(2.0)
            right_motor.setVelocity(-2.0)
        giro_steps -= 1
        if giro_steps <= 0:
            estado = AVANZAR

    # --- Imprimir mapa ---
    if step_count % 200 == 0:
        print(f"\n--- Mapa en paso {step_count} ---")
        for row in map_grid:
            print(' '.join(str(cell) for cell in row))

    step_count += 1
