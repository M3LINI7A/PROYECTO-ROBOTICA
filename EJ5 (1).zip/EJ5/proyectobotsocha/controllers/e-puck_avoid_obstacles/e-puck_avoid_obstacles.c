from controller import Robot

# Creamos la instancia del Robot
robot = Robot()

# Obtenemos el paso de tiempo básico del mundo actual
timestep = int(robot.getBasicTimeStep())

# --- Configuración de los Motores ---
# Obtenemos acceso a los motores de las ruedas.
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')

# Ponemos los motores en modo de rotación continua (esencial para las ruedas)
# y establecemos la velocidad inicial en 0.
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)


# --- Bucle Principal del Robot ---
while robot.step(timestep) != -1:
    # Le damos una velocidad a las ruedas para que el robot avance.
    # La velocidad máxima del e-puck es aprox. 6.28.
    # Un valor de 2.0 es una buena velocidad para empezar.
    left_motor.setVelocity(2.0)
    right_motor.setVelocity(2.0)