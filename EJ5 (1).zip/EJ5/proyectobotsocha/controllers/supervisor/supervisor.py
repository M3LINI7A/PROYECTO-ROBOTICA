import numpy as np

# 📐 Parámetros del grid
GRID_RESOLUTION = 0.04  # tamaño de celda en metros
WORLD_X_MIN, WORLD_X_MAX = -0.5, 0.5
WORLD_Y_MIN, WORLD_Y_MAX = -0.5, 0.5

GRID_WIDTH = int((WORLD_X_MAX - WORLD_X_MIN) / GRID_RESOLUTION)
GRID_HEIGHT = int((WORLD_Y_MAX - WORLD_Y_MIN) / GRID_RESOLUTION)

# 🧱 Inicializar matriz vacía
grid = np.zeros((GRID_HEIGHT, GRID_WIDTH), dtype=int)

def world_to_grid(x, y):
    """Convierte coordenadas del mundo a índices de la matriz"""
    gx = int((x - WORLD_X_MIN) / GRID_RESOLUTION)
    gy = int((y - WORLD_Y_MIN) / GRID_RESOLUTION)
    return gy, gx  # fila, columna

def mark_obstacle(x, y, size_x, size_y, value):
    """Marca una región como ocupada en la matriz con un valor específico"""
    x_min = x - size_x / 2
    x_max = x + size_x / 2
    y_min = y - size_y / 2
    y_max = y + size_y / 2

    gx_min, gy_min = world_to_grid(x_min, y_min)
    gx_max, gy_max = world_to_grid(x_max, y_max)

    for i in range(gy_min, gy_max + 1):
        for j in range(gx_min, gx_max + 1):
            if 0 <= i < GRID_HEIGHT and 0 <= j < GRID_WIDTH:
                grid[i, j] = value

def mark_wall(x, y, size_x, size_y):
    mark_obstacle(x, y, size_x, size_y, value=1)

def mark_box(x, y, size_x, size_y):
    mark_obstacle(x, y, size_x, size_y, value=2)

# 🧱 Paredes (Wall)
walls = [
    (0.29, 0.36, 0.01, 0.3),
    (0.29, -0.36, 0.01, 0.3),
    (-0.29, 0.36, 0.01, 0.3),
    (-0.29, -0.04, 0.01, 0.3),
    (-0.4, 0.05, 0.22, 0.01),
    (-0.18, 0.32, 0.22, 0.01),
    (0.18, 0.32, 0.22, 0.01),
    (0.39, 0.0, 0.22, 0.01),
    (0.07, -0.36, 0.01, 0.3),
    (-0.15, -0.36, 0.01, 0.3),
    (0.28, 0.0, 0.01, 0.2),
    (0.07, -0.21, 0.22, 0.01),
    (0.0, 0.36, 0.01, 0.3)
]

# 📦 Cajas (Box)
boxes = [
    (0.31, 0.03, 0.04, 0.04),
    (0.1, 0.35, 0.04, 0.04),
    (-0.1, 0.35, 0.04, 0.04),
    (0.31, -0.03, 0.04, 0.04),
    (-0.32, 0.08, 0.04, 0.04),
    (0.1, -0.24, 0.04, 0.04),
    (0.04, -0.24, 0.04, 0.04),
    (-0.47, -0.35, 0.05, 0.3)
]

# 🧱 Marcar paredes
for x, y, sx, sy in walls:
    mark_wall(x, y, sx, sy)

# 📦 Marcar cajas
for x, y, sx, sy in boxes:
    mark_box(x, y, sx, sy)

# ✅ Mostrar resultado
np.set_printoptions(threshold=np.inf)
print("GRID:")
print(grid)
