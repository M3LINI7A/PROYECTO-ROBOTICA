# task_handler.py

from queue import PriorityQueue

class TaskHandler:
    def __init__(self):
        self.queue = PriorityQueue()
        self.completed = []

    def add_task(self, priority, box_id):
        self.queue.put((priority, box_id))

    def get_next_task(self):
        if not self.queue.empty():
            return self.queue.get()[1]
        return None

    def confirm_delivery(self, robot_id, box_id):
        self.completed.append((robot_id, box_id))
        print(f"[CONFIRMED] {robot_id} delivered {box_id}")

    def get_completed(self):
        return self.completed
