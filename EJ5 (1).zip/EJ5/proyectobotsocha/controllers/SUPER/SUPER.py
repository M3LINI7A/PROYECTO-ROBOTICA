from controller import Supervisor, Receiver, Emitter

robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

emitter = robot.getDevice('emitter(1)')
receiver = robot.getDevice('receiver(1)')
receiver.setChannel(0)
receiver.enable(timestep)

# --- Obtener coordenadas de cajas ---
boxes_recojo = [robot.getFromDef(f"BOX({i})") for i in range(1, 8)]
box_entrega = robot.getFromDef("BOX(8)")

# --- Extraer posiciones ---
tareas = []
for i, box in enumerate(boxes_recojo, start=1):
    pos = box.getField("translation").getSFVec3f()
    tareas.append((i, (pos[0], pos[2])))  # prioridad = i

entrega_pos = box_entrega.getField("translation").getSFVec3f()
entrega_coords = (entrega_pos[0], entrega_pos[2])

robots_libres = set()

# --- Bucle principal ---
while robot.step(timestep) != -1:
    # --- Recepción de mensajes ---
    while receiver.getQueueLength() > 0:
        msg = receiver.getData().decode('utf-8')
        if msg.startswith("READY:"):
            robot_id = int(msg.split(":")[1])
            robots_libres.add(robot_id)
        elif msg.startswith("DELIVERED:"):
            robot_id = int(msg.split(":")[1])
            print(f"✅ Robot {robot_id} entregó objeto")
        receiver.nextPacket()

    # --- Asignación de tareas ---
    tareas.sort(key=lambda x: x[0])
    while tareas and robots_libres:
        robot_id = robots_libres.pop()
        _, (x, z) = tareas.pop(0)
        mensaje = f"TASK:{x},{z}:{entrega_coords[0]},{entrega_coords[1]}"
        emitter.setChannel(robot_id)
        emitter.send(mensaje.encode('utf-8'))
        print(f"📡 Asignando a robot {robot_id}: {mensaje}")
