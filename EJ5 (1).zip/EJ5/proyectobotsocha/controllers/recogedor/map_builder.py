# map_builder.py

# Parámetros del entorno
MAP_ORIGIN = [-0.48, -0.46]  # esquina inferior izquierda del mundo
MAP_WIDTH = 0.87
MAP_HEIGHT = 0.82
CELL_SIZE = 0.02  # resolución más precisa

GRID_COLS = int(MAP_WIDTH / CELL_SIZE)
GRID_ROWS = int(MAP_HEIGHT / CELL_SIZE)

# Conversión de coordenadas
def world_to_grid(x, z):
    gx = int((x - MAP_ORIGIN[0]) / CELL_SIZE)
    gz = int((z - MAP_ORIGIN[1]) / CELL_SIZE)
    return gx, gz

def grid_to_world(gx, gz):
    x = MAP_ORIGIN[0] + gx * CELL_SIZE + CELL_SIZE / 2
    z = MAP_ORIGIN[1] + gz * CELL_SIZE + CELL_SIZE / 2
    return x, z

# Marcar área ocupada por un objeto
def mark_obstacle_area(grid, node):
    pos = node.getField("translation").getSFVec3f()
    size_field = node.getField("size")
    if size_field:
        size = size_field.getSFVec3f()
    else:
        size = [CELL_SIZE, CELL_SIZE, CELL_SIZE]  # fallback

    x_min = pos[0] - size[0] / 2
    x_max = pos[0] + size[0] / 2
    z_min = pos[2] - size[2] / 2
    z_max = pos[2] + size[2] / 2

    gx_min, gz_min = world_to_grid(x_min, z_min)
    gx_max, gz_max = world_to_grid(x_max, z_max)

    for gx in range(gx_min, gx_max + 1):
        for gz in range(gz_min, gz_max + 1):
            if 0 <= gx < GRID_COLS and 0 <= gz < GRID_ROWS:
                grid[gz][gx] = 1

# Construcción del mapa lógico
def build_map(supervisor, box_ids, robot_ids=[], wall_ids=[]):
    grid = [[0 for _ in range(GRID_COLS)] for _ in range(GRID_ROWS)]

    for box_id in box_ids:
        node = supervisor.getFromDef(box_id)
        if node:
            mark_obstacle_area(grid, node)

    for robot_id in robot_ids:
        node = supervisor.getFromDef(robot_id)
        if node:
            mark_obstacle_area(grid, node)

    for wall_id in wall_ids:
        node = supervisor.getFromDef(wall_id)
        if node:
            mark_obstacle_area(grid, node)

    return grid
