# navigator.py

from map_builder import grid_to_world

def next_target(path, current_index):
    if current_index < len(path):
        gx, gz = path[current_index]
        return grid_to_world(gx, gz)
    return None

def reached_target(current_pos, target_pos, threshold=0.02):
    dx = current_pos[0] - target_pos[0]
    dz = current_pos[2] - target_pos[1]
    return (dx**2 + dz**2)**0.5 < threshold
