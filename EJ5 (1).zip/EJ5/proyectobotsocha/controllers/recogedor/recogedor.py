from controller import Robot, Receiver, GPS, Compass, Emitter
import json
import numpy as np
import heapq

# Inicializar robot y timestep
robot = Robot()
timestep = int(robot.getBasicTimeStep())
robot_name = robot.getName()

# Dispositivos
receiver = robot.getDevice("receiver(1)")
receiver.enable(timestep)

gps = robot.getDevice("gps")
gps.enable(timestep)

compass = robot.getDevice("compass")
compass.enable(timestep)

emitter = robot.getDevice("emitter(1)")
emitter.setChannel(1)

left_motor = robot.getDevice("left wheel motor")
right_motor = robot.getDevice("right wheel motor")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

ps = []
for i in range(8):
    sensor = robot.getDevice(f"ps{i}")
    sensor.enable(timestep)
    ps.append(sensor)

# Parámetros del grid (se actualizan con el mensaje)
GRID_RESOLUTION = 0.04
WORLD_X_MIN, WORLD_Y_MIN = -0.5, -0.5
GRID_HEIGHT = 0  # Se define luego

def grid_to_world(gy, gx):
    gy = GRID_HEIGHT - 1 - gy
    x = WORLD_X_MIN + gx * GRID_RESOLUTION + GRID_RESOLUTION / 2
    y = WORLD_Y_MIN + gy * GRID_RESOLUTION + GRID_RESOLUTION / 2
    return x, y

def get_current_orientation():
    north = compass.getValues()
    angle = np.arctan2(north[0], north[2])
    directions = ["S", "E", "W", "N"]
    index = int(((angle + np.pi) / (2 * np.pi)) * 4) % 4
    return directions[index]

def obstacle_detected(threshold=250.0):
    front_indices = [0, 1, 2, 5, 6, 7]
    return any(ps[i].getValue() > threshold for i in front_indices)

def avoid_obstacle():
    print("🔄 Maniobra de evasión...")
    left_motor.setVelocity(-2.0)
    right_motor.setVelocity(-2.0)
    for _ in range(10):
        robot.step(timestep)
    left_motor.setVelocity(2.0)
    right_motor.setVelocity(-2.0)
    for _ in range(15):
        robot.step(timestep)
    left_motor.setVelocity(0)
    right_motor.setVelocity(0)

def rotate_90(clockwise=True):
    initial = compass.getValues()
    initial_angle = np.arctan2(initial[0], initial[2])
    delta = -np.pi / 2 if clockwise else np.pi / 2
    #delta = np.pi / 2 if clockwise else -np.pi / 2
    target_angle = initial_angle + delta
    rotate_to_angle(target_angle)
def rotate_m90(clockwise=True):
    initial = compass.getValues()
    initial_angle = np.arctan2(initial[0], initial[2])
    print(f"📍 Ángulo inicial: {np.degrees(initial_angle):.2f}°")

    delta = -np.pi / 2 if clockwise else np.pi / 2
    target_angle = initial_angle + delta +delta
    print(f"🎯 Ángulo objetivo: {np.degrees(target_angle):.2f}°")

    rotate_to_mangle(target_angle)


def rotate_to_mangle():
    max_speed = 6.28
    Kp = 2.0
    error_threshold = 0.05  # ~3°
    timeout = 1.7  # segundos

    def normalize(angle):
        while angle > np.pi:
            angle -= 2 * np.pi
        while angle < -np.pi:
            angle += 2 * np.pi
        return angle

    # Obtener ángulo actual
    initial = compass.getValues()
    initial_angle = np.arctan2(initial[0], initial[2])
    print(f"📍 Ángulo inicial: {np.degrees(initial_angle):.2f}°")

    # Calcular ángulo objetivo: giro antihorario de 90°
    target_angle = normalize(initial_angle - np.pi / 2)
    print(f"🎯 Ángulo objetivo: {np.degrees(target_angle):.2f}°")

    start_time = robot.getTime()

    while robot.step(timestep) != -1:
        current = compass.getValues()
        current_angle = np.arctan2(current[0], current[2])
        error = normalize(target_angle - current_angle)

        print(f"🔄 Ángulo actual: {np.degrees(current_angle):.2f}°, error: {np.degrees(error):.2f}°")

        if abs(error) < error_threshold:
            print("✅ Giro antihorario de 90° completado.")
            break

        if robot.getTime() - start_time > timeout:
            print("⏱️ Tiempo límite alcanzado.")
            break

        # Forzar giro antihorario
        velocity = -abs(Kp * error)
        velocity = np.clip(velocity, -max_speed * 0.3, -0.05)

        left_motor.setVelocity(velocity)
        right_motor.setVelocity(-velocity)

    left_motor.setVelocity(0)
    right_motor.setVelocity(0)
    print("⛔ Motores detenidos.")


def rotate_to_angle(target_angle):
    max_speed = 6.28
    Kp = 2.0
    error_threshold = 0.05  # radianes (~3°)
    timeout = 3.0  # segundos

    def normalize(angle):
        while angle > np.pi:
            angle -= 2 * np.pi
        while angle < -np.pi:
            angle += 2 * np.pi
        return angle

    target_angle = normalize(target_angle)
    start_time = robot.getTime()

    while robot.step(timestep) != -1:
        current = compass.getValues()
        current_angle = np.arctan2(current[0], current[2])
        error = normalize(target_angle - current_angle)

        print(f"🔄 Ángulo actual: {np.degrees(current_angle):.2f}°, error: {np.degrees(error):.2f}°")

        if abs(error) < error_threshold:
            print("✅ Giro completado.")
            break

        if robot.getTime() - start_time > timeout:
            print("⏱️ Tiempo límite alcanzado.")
            break

        velocity = Kp * error
        velocity = np.clip(velocity, -max_speed * 0.3, max_speed * 0.3)

        left_motor.setVelocity(-velocity)
        right_motor.setVelocity(velocity)

    left_motor.setVelocity(0)
    right_motor.setVelocity(0)
    print("⛔ Motores detenidos.")


def rotate_to_direction(current, target):
    directions = ["S", "E", "N", "W"]
    idx_current = directions.index(current)
    idx_target = directions.index(target)
    diff = (idx_target - idx_current) % 4

    print(f"🔄 Girando de {current} a {target} (diff={diff})")

    if diff == 0:
        return current
    elif diff == 1:
        rotate_90(clockwise=True)
    elif diff == 2:
        rotate_90(clockwise=True)
        rotate_90(clockwise=True)
    elif diff == 3:
        rotate_to_mangle()

        #rotate_m90(clockwise=True)
        #rotate_90(clockwise=False)
        #rotate_90(clockwise=True)
        

    return target

def move_to_cell(cell):
    target_x, target_y = grid_to_world(cell[0], cell[1])
    max_speed = 6.28
    stuck_counter = 0
    last_pos = gps.getValues()

    while robot.step(timestep) != -1:
        pos = gps.getValues()
        dx = target_x - pos[0]
        dy = target_y - pos[1]
        distance = np.hypot(dx, dy)

        movement = np.hypot(pos[0] - last_pos[0], pos[1] - last_pos[1])
        last_pos = pos

        if distance < 0.005:
            left_motor.setVelocity(0)
            right_motor.setVelocity(0)
            break

        if movement < 0.0005:
            stuck_counter += 1
        else:
            stuck_counter = 0

        if stuck_counter > 20:
            print("🛑 Atascado. Ejecutando evasión...")
            avoid_obstacle()
            break

        left_motor.setVelocity(max_speed * 0.8)
        right_motor.setVelocity(max_speed * 0.8)

def get_direction(from_cell, to_cell):
    dy = to_cell[0] - from_cell[0]
    dx = to_cell[1] - from_cell[1]
    if dy == -1 and dx == 0:
        return "N"
    elif dy == 1 and dx == 0:
        return "S"
    elif dy == 0 and dx == 1:
        return "W"
    elif dy == 0 and dx == -1:
        return "E"
    else:
        return None

def is_free(grid, y, x):
    return 0 <= y < grid.shape[0] and 0 <= x < grid.shape[1] and grid[y, x] == 0

def find_adjacent_free(grid, y, x):
    for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
        ny, nx = y + dy, x + dx
        if is_free(grid, ny, nx):
            return ny, nx
    return None

def validate_position(grid, pos, label):
    y, x = pos
    if not is_free(grid, y, x):
        print(f"⚠️ {label} ({y}, {x}) bloqueado. Buscando celda libre...")
        new_pos = find_adjacent_free(grid, y, x)
        if new_pos:
            print(f"✅ {label} ajustado a: {new_pos}")
            return new_pos
        else:
            print(f"❌ No hay celdas libres cerca de {label}")
            return None
    return pos

def astar(grid, start, goal):
    rows, cols = grid.shape
    open_set = []
    heapq.heappush(open_set, (0, start))
    came_from = {}
    g_score = {start: 0}

    def heuristic(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    while open_set:
        _, current = heapq.heappop(open_set)
        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            return path[::-1]

        for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
            neighbor = (current[0] + dy, current[1] + dx)
            if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols:
                if grid[neighbor[0], neighbor[1]] in [1, 2]:
                    continue
                tentative_g = g_score[current] + 1
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score = tentative_g + heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score, neighbor))
    return []

def print_grid_with_path(grid, path):
    grid_copy = np.array(grid, dtype=str)
    for y in range(grid_copy.shape[0]):
        for x in range(grid_copy.shape[1]):
            if grid_copy[y, x] == '1':
                grid_copy[y, x] = '█'
            elif grid_copy[y, x] == '2':
                grid_copy[y, x] = '▓'
            else:
                grid_copy[y, x] = '.'
    for y, x in path:
        grid_copy[y, x] = '•'
    print("\n🗺 Grid con ruta:")
    for row in grid_copy:
        print("".join(row))

# Esperar mensaje
while receiver.getQueueLength() == 0:
    robot.step(timestep)

message = receiver.getString()
data = json.loads(message)
receiver.nextPacket()

# Verificar destinatario
if data.get("target") != robot_name:
    print(f"📭 Mensaje dirigido a {data.get("target")}, ignorado por {robot_name}.")
    while True:
        robot.step(timestep)

# Procesar datos del mensaje
grid = np.array(data["grid"])
target_box = data["pickup_target"]
pickup_grid = data["pickup_grid"]
delivery_grid = data["delivery_grid"]

# Parámetros del entorno
GRID_RESOLUTION = data["grid_resolution"]
GRID_HEIGHT = data["grid_height"]
WORLD_X_MIN = data["world_x_min"]
WORLD_Y_MIN = data["world_y_min"]

# Determinar posición actual del robot
pos = gps.getValues()
gx = int((pos[1] - WORLD_Y_MIN) / GRID_RESOLUTION)
gy = int((pos[0] - WORLD_X_MIN) / GRID_RESOLUTION)
start_position = validate_position(grid, (gy, gx), "Inicio")
goal_position = validate_position(grid, tuple(pickup_grid[target_box]), f"Destino ({target_box})")

# Ejecutar ruta con orientación cardinal
if start_position and goal_position:
    path = astar(grid, start_position, goal_position)
    if not path:
        print(f"⚠️ No se encontró ruta desde {start_position} hasta {goal_position}.")
    else:
        print(f"🚶‍♂️ Ruta calculada: {path}")
        print(f"📏 Longitud de ruta: {len(path)} celdas")
        print_grid_with_path(grid, path)

        orientation = get_current_orientation()
        print(f"🧭 Orientación inicial: {orientation}")

        current_index = 0
        orientation = get_current_orientation()

        while current_index < len(path) - 1:
            # Obtener posición actual por GPS
            pos = gps.getValues()
            gx = int((pos[1] - WORLD_Y_MIN) / GRID_RESOLUTION)
            gy = int((pos[0] - WORLD_X_MIN) / GRID_RESOLUTION)
            current_cell = (gy, gx)

            # Verificar si estamos en la celda esperada
            expected_cell = path[current_index]
            if current_cell != expected_cell:
                print(f"⚠️ Desalineado: GPS indica {current_cell}, ruta espera {expected_cell}")
                # Opcional: buscar celda más cercana en la ruta
                current_index = min(range(len(path)), key=lambda i: np.hypot(path[i][0] - gy, path[i][1] - gx))
                print(f"🔄 Reajustando índice de ruta a {current_index}")

            # Determinar siguiente celda
            next_index = current_index + 1
            if next_index >= len(path):
                break

            from_cell = path[current_index]
            to_cell = path[next_index]
            direction = get_direction(from_cell, to_cell)

            print(f"➡️ De {from_cell} a {to_cell} → dirección deseada: {direction}")
            print(f"🧭 Orientación actual: {orientation}")

            if direction:
                orientation = rotate_to_direction(orientation, direction)
                move_to_cell(to_cell)
                current_index += 1
            else:
                print(f"⚠️ Movimiento no cardinal entre {from_cell} y {to_cell}")
                current_index += 1

        print("✅ Ruta completada.")

        # Enviar mensaje de recogida completada
        completion_msg = {
            "sender": robot_name,
            "status": "pickup_complete",
            "box": target_box
        }
        emitter.send(json.dumps(completion_msg).encode("utf-8"))
        print(f"📤 Mensaje enviado: {completion_msg}")
else:
    print("❌ Posiciones inválidas. No se puede calcular ruta.")
